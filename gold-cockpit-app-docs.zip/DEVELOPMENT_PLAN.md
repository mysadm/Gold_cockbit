# Development Plan · from single file to application

Current state: v1.0 — one HTML file on GitHub Pages. Everything below builds on it without throwing it away.

## Guiding decisions

1. **PWA before native.** An installable Progressive Web App gets 90% of the "real app" feel (home-screen icon, full-screen, offline shell, push-capable) with zero app-store friction and no second codebase. Native wrapping comes later only if store distribution matters.
2. **Backend only when a feature demands it.** Three features eventually will: price alerts, key protection, and history. Until then, static hosting keeps cost at zero and attack surface near zero.
3. **The single-file constraint dies at Phase 2.** It served deployment simplicity; a build step (Vite) pays for itself once the code passes ~1,500 lines.

---

## Phase 1 — Hardening (1–2 evenings)

Goal: the current tool, but trustworthy enough to act on.

- [ ] **State persistence.** Save weights, budget, premium, watchlist colors, and last prices to localStorage; restore on open. Currently everything resets per session.
- [ ] **Price history sparkline.** Store each pulled price with a timestamp (localStorage, capped at 90 entries). Draw a small 30-day line under the ounce cell. Context for "is today's price high?"
- [ ] **Offshore EGP field.** Second FX input for the parallel-market rate with the spread displayed. The official/offshore gap is the most important number in the pound layer and the tool currently ignores it.
- [ ] **Per-karat premium.** Bullion and jewelry carry different spreads; one premium field misprices both.
- [ ] **Analysis log.** Keep the last 5 AI analyses with timestamps so verdicts can be compared over weeks.

Deliverable: still one file, still GitHub Pages.

## Phase 2 — PWA (1 weekend)

Goal: installs like an app, opens offline, restructured for growth.

- [ ] Split into modules with **Vite**: `state.js`, `feeds.js`, `analyst.js`, `ui/`, `i18n/`. Output remains a static bundle for Pages.
- [ ] **Web app manifest** — name, icons (the vault-black + gold identity), standalone display, RTL-aware.
- [ ] **Service worker** — cache the shell for instant offline open; show last-known prices with a "stale" badge when offline.
- [ ] **GitHub Actions** — push to main → build → deploy. No manual uploads.

Deliverable: `gold.paymint-eg.com`-ready PWA (custom domain is one CNAME record).

## Phase 3 — Alerts backend (1–2 weekends)

Goal: the tool tells you when a tranche trigger fires, instead of you checking.

- [ ] **Cloudflare Worker + cron** (free tier suffices): pull prices every 30 min, store in Workers KV.
- [ ] **Alert rules**: spot crosses a scenario band edge; EGP moves >1% in a day; weighted-target delta crosses a threshold; Tranche window opening.
- [ ] **Delivery**: web push (now possible via the PWA) and/or a Telegram bot — Telegram is more reliable on iOS and trivial to build.
- [ ] **API key proxy (optional but right)**: move the Anthropic call into the Worker with the key stored as a Worker secret. The browser never holds the key again. Add a simple access token so only you can trigger analyses.

Cost at this phase: ~$0–5/month.

## Phase 4 — Native wrapper (optional, 1 weekend)

Only if App Store presence or iOS-native notifications become necessary.

- [ ] **Capacitor** wrap of the Phase 2 build — same code, native shell.
- [ ] Native push notifications replacing web push on iOS.
- [ ] Biometric lock (Face ID) before showing positions.

Skip this phase entirely if the PWA + Telegram alerts feel sufficient. They probably will.

## Phase 5 — Beyond gold (open horizon)

The scenario engine, DCA tracker, and AI analyst are asset-agnostic. Candidates, in order of fit with the existing EGP-hedge thesis:

1. **USD cash position** alongside gold — the same dual-layer math, trivially
2. **Egyptian gold ETFs / certificates** — instrument comparison against physical
3. **Multi-user** — at that point this stops being a personal tool and becomes a product decision: auth, database, compliance questions. Decide deliberately, not by drift.

---

## Risks worth writing down

- **Feed mortality.** Free APIs die without notice. The 4-source chain mitigates; Phase 3's server-side pull with KV cache solves it properly.
- **Key exposure until Phase 3.** localStorage on a personal device is acceptable risk for personal use; it is the first thing to fix if anyone else ever touches the tool.
- **Anthropic API changes.** The `pause_turn` handling and direct-browser-access header are current behavior; pin the API version header and re-test on SDK announcements.
- **Framework staleness.** The May 2026 scenario bands are hardcoded. Phase 1 should make bands editable in the UI so the framework evolves without redeploying.

## Effort summary

| Phase | Effort | Cost | Outcome |
|---|---|---|---|
| 1 — Hardening | 1–2 evenings | $0 | Trustworthy daily tool |
| 2 — PWA | 1 weekend | $0 | Installable app |
| 3 — Alerts | 1–2 weekends | ~$0–5/mo | It watches the market for you |
| 4 — Native | 1 weekend | $99/yr (Apple) | Store presence, Face ID |
| 5 — Multi-asset | open | — | Product decision |
